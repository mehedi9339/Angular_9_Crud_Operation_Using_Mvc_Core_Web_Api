﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Net.Http.Headers;
using NgProductsPro.Context;
using NgProductsPro.Models;  

namespace NgProductsPro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly databaseContext _context;
        private IHostingEnvironment _env;

        public ProductsController(databaseContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;

        }

        // GET: api/Products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            return await _context.Products.ToListAsync();
        }

        // GET: api/Products/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            return product;
        }

        // PUT: api/Products/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest();
            }

            _context.Entry(product).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Products
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public IActionResult PostProduct()
        {
            //var files = Request.Form.Files;
            //IFormFile file;
            //string imagePath = "";

            //string fpath = Path.Combine(_env.WebRootPath, "ProductImage");
            //if (!Directory.Exists(fpath))
            //{
            //    Directory.CreateDirectory(fpath);
            //}

            ////string id = Request.Form["id"].ToString();
            //string pname = Request.Form["pname"].ToString();
            //string price = Request.Form["price"].ToString();
            //string cat = Request.Form["category"].ToString();
            //string des = Request.Form["description"].ToString();

            //if (files.Count > 0)
            //{
            //    file = Request.Form.Files[0];
            //    string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.ToString().Trim();
            //    string ext = Path.GetExtension(fileName);
            //    string fileWithoutExt = Path.GetFileNameWithoutExtension(fileName);
            //    string filePath = Path.Combine(fpath, (fileWithoutExt + "_" + pname + ext));

            //    using (var stream = new FileStream(filePath, FileMode.Create))
            //    {
            //        file.CopyTo(stream);
            //    }


            //    imagePath = "/ProductImage/" + fileWithoutExt + "_" + pname + ext;
            //}


            //var prd = new Product
            //{
            //    //Id = Int32.Parse(id),
            //    Name = pname,
            //    Description = des,
            //    CatID = Int32.Parse(cat),
            //    Price = float.Parse(price),
            //    ImagePath = imagePath
            //};

            //_context.Add(prd);

            //if (_context.SaveChanges() > 0)
            //{
            //    return Created("api/items", prd);
            //}
            //return BadRequest();


            string fpath = Path.Combine(_env.WebRootPath, "ProductImage");
            if (!Directory.Exists(fpath))
            {
                Directory.CreateDirectory(fpath);
            }

            var file = Request.Form.Files[0];
            string id = Request.Form["id"].ToString();
            string pname = Request.Form["pname"].ToString();
            string price = Request.Form["price"].ToString();
            string cat = Request.Form["category"].ToString();
            string des = Request.Form["description"].ToString();
            string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.ToString().Trim('"');
            string ext = Path.GetExtension(fileName);
            string filewithoutext = Path.GetFileNameWithoutExtension(fileName);
            string filepath = Path.Combine(fpath, (filewithoutext + "_" + pname + ext));
            using (var stream = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            string imagePath = "/ProductImage/" + filewithoutext + "_" + pname + ext;
            
            if (id == "")
            {
                var prd = new Product
                {
                    Name = pname,
                    Description = des,
                    CatID = Int32.Parse(cat),
                    Price = float.Parse(price),
                    ImagePath = imagePath

                };
                _context.Add(prd);
                if (_context.SaveChanges() > 0)
                {
                    return Created("api/items", prd);

                }
            }
            else
            {
                var prd = new Product
                {
                    Id = Int32.Parse(id),
                    Name = pname,
                    Description = des,
                    CatID = Int32.Parse(cat),
                    Price = float.Parse(price),
                    ImagePath = imagePath

                };
                _context.Update(prd);
                if (_context.SaveChanges() > 0)
                {
                    return Created("api/items", prd);

                }
            }
            
            
            return BadRequest();
        }

        // DELETE: api/Products/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Product>> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return product;
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}

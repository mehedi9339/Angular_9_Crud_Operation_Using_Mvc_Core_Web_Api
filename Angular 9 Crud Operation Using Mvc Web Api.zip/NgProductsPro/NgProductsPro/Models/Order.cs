﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NgProductsPro.Models
{
    public class Order
    {
        public int Id { get; set; }
        [DataType(DataType.Date)]

        public DateTime Orderdate { get; set; }
        [ForeignKey("Customer")]
        public int CustId { get; set; }
        public int TotalQty { get; set; }
        public float TotalPrice { get; set; }
        public Customer Customer { get; set; }
        public ICollection<OrderDetails> OrderDetails { get; set; }
    }
}

import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/Models/order.model';
import { Customer } from 'src/app/Models/customer.model';
import { CustomerSrvService } from 'src/app/Services/customer-srv.service';
import { Router, ActivatedRoute } from '@angular/router';

import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-or-edit-customer',
  templateUrl: './add-or-edit-customer.component.html',
  styleUrls: ['./add-or-edit-customer.component.css']
})

export class AddOrEditCustomerComponent implements OnInit {
  public customer: Customer;
  private customerData;
  constructor(
    public service: CustomerSrvService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    let id = this.activatedRoute.snapshot.paramMap.get("id");
    console.log(id);
    if (parseInt(id) == 0 || id == null) {
      this.customer = {
        "Id": 0,
        "Name": "",
        "Email": "",
        "Contact": "",
        "ShippingAddress": "",
        "Orders": []
      }
      console.log(this.customer);
    }
    else {
      this.service.getById(id).subscribe(s => {
        this.customerData = s;
        this.customer = {
          Id: this.customerData.id,
          Name: this.customerData.name,
          Email: this.customerData.email,
          Contact: this.customerData.contact,
          ShippingAddress: this.customerData.shippingAddress,
          Orders: []
        }
        // console.log(this.customer);
      })
    }
  }
  OnSubmit() {
    this.service.SaveOrUpdate(this.customer).subscribe(s => {
      this.router.navigate(["customers"]);
    })
  }
}


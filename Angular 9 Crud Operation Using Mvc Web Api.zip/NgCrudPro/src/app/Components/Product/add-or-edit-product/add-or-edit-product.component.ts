import { Component, OnInit, Sanitizer } from '@angular/core';
import { CategorySrvService } from 'src/app/Services/category-srv.service';
import { ProductSrvvService } from 'src/app/Services/product-srvv.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-add-or-edit-product',
  templateUrl: './add-or-edit-product.component.html',
  styleUrls: ['./add-or-edit-product.component.css']
})
export class AddOrEditProductComponent implements OnInit {
  categoryList;
  selectedFiles: File = null;
  product;
  fpath = environment.imgUrl;
  fileToUpload: any;
  imgUrl: any;
  public isDefaultImageVisible = true;
  public isChangeImageEnable = false;

  constructor(
    public catService: CategorySrvService,
    public prdService: ProductSrvvService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.catService.getAll().subscribe(c => {
      this.categoryList = c;
      console.log(c);
    })

    let id = this.activatedRoute.snapshot.paramMap.get("id");
    console.log("Id: " + id);

    if (parseInt(id) == 0 || id == null) {
      this.product = {
        "Id": 0,
        "Name": "",
        "Description": "",
        "CatID": 0,
        "ImagePath": "https://wolper.com.au/wp-content/uploads/2017/10/image-placeholder.jpg",
        "Price": 0,
      }
      console.log(this.product);
    }
    else {
      this.prdService.getById(id).subscribe(p => {
        this.product = p;
        console.log(p);
      })
      // this.prdService.saveOrUpdate(this.product).subscribe(p => {
      //   this.product = p;
      // })
    }
  }

  onChanged(e) {
    this.selectedFiles = <File>e.target.files[0];
    console.log(this.selectedFiles);
    this.fileToUpload = this.selectedFiles;
    this.isChangeImageEnable = true;
  }
  change() {
    this.isDefaultImageVisible = false;
    let reader = new FileReader();
    reader.onload = (event: any) => {
      this.imgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  saveProduct(Id, Name, Price, Description, CatId) {
    var formData = new FormData();
    formData.append("img", this.selectedFiles, this.selectedFiles.name);
    formData.append("id", Id.value);
    formData.append("pname", Name.value);
    formData.append("price", Price.value);
    formData.append("description", Description.value);
    formData.append("category", CatId.value);
    console.log(this.selectedFiles);
    this.prdService.saveOrUpdate(formData).subscribe(p => {
      this.router.navigate(["products"]);
    })
  }
}

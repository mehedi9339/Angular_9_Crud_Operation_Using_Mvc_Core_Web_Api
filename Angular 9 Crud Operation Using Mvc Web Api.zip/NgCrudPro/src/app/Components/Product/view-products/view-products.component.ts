import { Component, OnInit } from '@angular/core';
import { ProductSrvvService } from 'src/app/Services/product-srvv.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  constructor(public service: ProductSrvvService, private http: HttpClient) { }
  productList;
  fpath = environment.imgUrl;
  ngOnInit(): void {
    this.loadProducts();
  }
  loadProducts() {
    this.service.getAll().subscribe(p => {
      this.productList = p;
      console.log(p[2].catID);
    })
  }
  // delete(id: number) {
  //   this.http.delete(this.id).subscribe(p => {
  //     console.log("deleted" + id);
  //     this.loadProducts();
  //   })
  // }
}

import { Component, OnInit } from '@angular/core';
import { CategorySrvService } from 'src/app/Services/category-srv.service';

@Component({
  selector: 'app-view-category',
  templateUrl: './view-category.component.html',
  styleUrls: ['./view-category.component.css']
})
export class ViewCategoryComponent implements OnInit {
  categories;
  constructor(public service: CategorySrvService) { }

  ngOnInit(): void {
    this.loadCategories();
  }
  loadCategories() {
    this.service.getAll().subscribe(s => {
      console.log(s);
      this.categories = s;
    })
  }

}

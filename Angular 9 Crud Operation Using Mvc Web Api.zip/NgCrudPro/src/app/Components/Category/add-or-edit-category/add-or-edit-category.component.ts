import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Models/category.model';
import { CategorySrvService } from 'src/app/Services/category-srv.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-or-edit-category',
  templateUrl: './add-or-edit-category.component.html',
  styleUrls: ['./add-or-edit-category.component.css']
})
export class AddOrEditCategoryComponent implements OnInit {
  public category: Category;
  categories;
  private categoryData;
  isSub: boolean = false;
  constructor(
    public service: CategorySrvService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    let id = this.activatedRoute.snapshot.paramMap.get("id");
    console.log(id);
    this.loadCategories();
    if (parseInt(id) == 0 || id == null) {
      this.category = {
        "Id": 0,
        "Name": "",
        "Description": "",
        "ParentId": 0
      }
      console.log(this.category);
    }
    else {
      this.service.getById(id).subscribe(s => {
        this.categoryData = s;
        this.category = {
          Id: this.categoryData.id,
          Name: this.categoryData.name,
          Description: this.categoryData.description,
          ParentId: this.categoryData.parentId
        }
        // console.log(this.category);
      })
    }

  }
  OnSubmit() {
    this.service.SaveOrUpdate(this.category).subscribe(s => {
      this.router.navigate(["categories"]);
    })
  }
  loadCategories() {
    this.service.getAll().subscribe(s => {
      console.log(s);
      this.categories = s;
    })
  }
  toggleChange(e) {
    console.log(e.target.checked)
    this.isSub = e.target.checked;
  }
}

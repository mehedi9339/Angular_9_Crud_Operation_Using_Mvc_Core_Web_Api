import { Order } from './order.model'
import { Product } from './product.model'

export class OrderDetails {
    Id: number
    OrderID: number
    PrdID: number
    Qty: number
    Order: Order
    Product: Product
}

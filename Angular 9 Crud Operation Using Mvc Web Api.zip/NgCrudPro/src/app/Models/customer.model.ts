import { Order } from './order.model';

export class Customer {
    Id: number;
    Name: string;
    Email: string;
    Contact: string;
    ShippingAddress: string;
    Orders: Order[];
}

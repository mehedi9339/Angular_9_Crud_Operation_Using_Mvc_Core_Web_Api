import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CategorySrvService {

  constructor(private http: HttpClient) { }
  getAll() {
    return this.http.get(environment.apiUrl + "categories");
  }
  getById(id) {
    return this.http.get(environment.apiUrl + "categories/" + id);
  }
  SaveOrUpdate(body) {
    return this.http.post(environment.apiUrl + "categories", body);
  }
  delete(id: number) {
    console.log(id);
    return this.http.delete(environment.apiUrl + "categories/" + id).subscribe(d => {
      console.log(d);
      this.getAll();
    });
  }
}

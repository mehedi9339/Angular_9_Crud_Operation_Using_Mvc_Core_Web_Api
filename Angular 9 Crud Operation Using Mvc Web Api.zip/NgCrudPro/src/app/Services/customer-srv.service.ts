import { Injectable } from '@angular/core';
import { Customer } from '../Models/customer.model';

import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CustomerSrvService {
  public customerData: Customer;
  constructor(private http: HttpClient) { }
  getAll() {
    return this.http.get(environment.apiUrl + "customers");
  }
  getById(id) {
    return this.http.get(environment.apiUrl + "customers/" + id);
  }
  SaveOrUpdate(body) {
    return this.http.post(environment.apiUrl + "customers", body);
  }
  delete(id: number) {
    console.log(id);
    return this.http.delete(environment.apiUrl + "customers/" + id).subscribe(d => {
      console.log(d);
      this.getAll();
    });
  }
}

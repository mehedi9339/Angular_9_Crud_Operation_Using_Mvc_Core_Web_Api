import { Injectable } from '@angular/core';
import { Product } from '../Models/product.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductSrvvService {
  product: Product;
  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(environment.apiUrl + "Products");
  }
  getById(id) {
    return this.http.get(environment.apiUrl + "Products/" + id)
  }
  saveOrUpdate(body) {
    console.log(body);
    return this.http.post(environment.apiUrl + "Products", body);
  }
  delete(id: number) {
    console.log(id);
    return this.http.delete(environment.apiUrl + "Products/" + id).subscribe(d => {
      console.log(d);
    });
  }
}
